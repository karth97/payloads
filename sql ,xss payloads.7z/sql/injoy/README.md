# Injoy
A multiprocessing blind SQL injection script to handle cases where sqlmap fails.

It's still a work in progress.
