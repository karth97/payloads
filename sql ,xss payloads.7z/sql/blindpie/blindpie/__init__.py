import logging


logging.basicConfig(format="%(asctime)s - %(funcName)20s() %(message)s", datefmt="%H:%M:%S", level=logging.CRITICAL)
